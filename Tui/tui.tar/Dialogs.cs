using Agent.Core;
using Agent.Core.Agent;
using Terminal.Gui.ViewBase;
using Terminal.Gui.Views;

namespace Agent.Tui;

/// <summary>TUI 配置向导弹窗：列表（已有 + 新建）或输入，Enter/双击即确定，按钮仅 [取消] [上一步]。
/// 可新建：base-url、key、model（模型目录真实拉取，可手输任意模型）；不可新建：variants（按提供商真实取值）。
/// /connect 四步 = base-url 列表 → key 列表 → model 列表 → variants 列表；
/// /key 一步 = 当前 provider 的 key 列表 + 新建；
/// /model 两步 = model 列表 → variants 列表；/variants 一步 = variants 列表。
/// 除 connect 外都基于当前 provider。ListView 默认选中第一项。
/// 不传 app 参数：统一用公开的 TuiRepl.App（仅 TUI 运行期间调用）。</summary>
internal static class Dialogs
{
    private enum StepDir { Next, Prev, Cancel }

    /// <summary>步骤函数签名（StepBaseUrl/StepKey/StepModel/StepVariants 统一）</summary>
    private delegate StepDir StepFn(string title, StepState s, bool hasPrev);

    /// <summary>步骤状态：正在配置的 provider（record 用 with 重建更新字段）</summary>
    private sealed class StepState(ProviderEntry entry)
    {
        public ProviderEntry Entry = entry;
    }

    /// <summary>列表步：ListView（默认选中第一项）+ 可选新建输入 + [上一步] [取消]。
    /// Enter/双击列表项 = 选中并进入下一步；新建输入框 Enter = 确定。
    /// 返回 (方向, 是否新建, 值)；已有项返回其原始值，新建返回输入文本。</summary>
    private static (StepDir Dir, bool IsNew, string Value) ListPickStep(
        string title, string[] labels, string[] values, string? newLabel, string inputLabel, bool secret, string hint, bool hasPrev)
    {
        var dir = StepDir.Cancel;
        var isNew = false;
        var value = "";
        string[] items = newLabel is null ? [.. labels] : [.. labels, newLabel];
        var list = new ListView
        {
            X = 2,
            Y = 1,
            Width = Dim.Fill(2),
            Height = Math.Max(3, items.Length + 1),
        };
        list.SetSource([.. items]);
        var newHint = new Label
        {
            X = 2,
            Y = items.Length + 3,
            Width = Dim.Fill(2),
            Text = inputLabel,
            Visible = false,
        };
        var field = new TextField
        {
            X = 2,
            Y = items.Length + 4,
            Width = Dim.Fill(2),
            Secret = secret,
            Visible = false,
        };
        if (newLabel is not null)
            list.ValueChanged += (_, _) =>
            {
                var isNewSel = (list.SelectedItem ?? 0) >= labels.Length;
                newHint.Visible = isNewSel;
                field.Visible = isNewSel;
            };
        var dialog = new Dialog
        {
            Title = title,
            Width = Math.Max(50, Math.Min(72, hint.Length + 20)),
            Height = items.Length + 11,
            X = Pos.Center(),
            Y = Pos.Center(),
            SchemeName = TuiRepl.ThemeName   // 套用主主题（深色）
        };
        dialog.Add(new Label { X = 2, Y = 0, Text = hint }, list, newHint, field);
        AddNavButtons(dialog, hasPrev, d => dir = d);
        // Enter/双击列表项 = Accept → 设值 → 吞掉命令（阻止冒泡派发给默认按钮=取消）→ 关闭对话框
        list.Accepting += (_, args) =>
        {
            DoNext();
            args.Handled = true;
            dialog.RequestStop();
        };
        // 新建输入框 Enter = 确定新建值
        field.Accepting += (_, args) =>
        {
            DoNext();
            args.Handled = true;
            dialog.RequestStop();
        };
        list.SelectedItem = 0;
        TuiRepl.App.Run(dialog);
        return (dir, isNew, value);

        void DoNext()
        {
            var sel = list.SelectedItem ?? 0;
            isNew = newLabel is not null && sel >= labels.Length;
            value = isNew ? field.Text : values[Math.Clamp(sel, 0, values.Length - 1)];
            dir = StepDir.Next;
        }
    }

    /// <summary>按顺序添加 [取消] [上一步] 按钮（列表/输入框自身承担确认，无「下一步/完成」按钮）</summary>
    private static void AddNavButtons(Dialog dialog, bool hasPrev, Action<StepDir> setDir)
    {
        var cancel = new Button { Text = "取消" };
        cancel.Accepting += (_, _) => setDir(StepDir.Cancel);
        dialog.AddButton(cancel);
        if (!hasPrev) return;
        var prev = new Button { Text = "上一步" };
        prev.Accepting += (_, _) => setDir(StepDir.Prev);
        dialog.AddButton(prev);
    }

    // ===== 命令 =====

    /// <summary>/connect 四步向导：base-url 列表 → key 列表 → model 列表 → variants 列表</summary>
    public static void Connect() => RunConfig("connect", true, StepBaseUrl, StepKey, StepModel, StepVariants);

    /// <summary>/key 一步：key 列表 → 更新当前 key</summary>
    public static void Key() => RunConfig("key", false, StepKey);

    /// <summary>/model 两步：model 列表 → variants 列表</summary>
    public static void Model() => RunConfig("model", false, StepModel, StepVariants);

    /// <summary>/variants 一步：variants 列表</summary>
    public static void Variants() => RunConfig("variants", false, StepVariants);

    /// <summary>会话选择弹窗（TUI 内）：历史会话 + 新建（新建可输入标题）。返回会话 id，取消返回 null。</summary>
    public static string? PickSession(SessionStore store, List<SessionStore.SessionInfo> sessions)
    {
        var labels = sessions.Select(s =>
        {
            var title = string.IsNullOrEmpty(s.Title) ? "(无标题)" : s.Title;
            var time = DateTimeOffset.FromUnixTimeSeconds(s.UpdatedAt).ToLocalTime().ToString("MM-dd HH:mm");
            return $"{time}  {title}  [{s.Count}条]";
        }).ToArray();
        var values = sessions.Select(s => s.Id).ToArray();
        var r = ListPickStep("选择会话", labels, values, "＋ 新建会话", "新会话标题:",
            secret: false, hint: "选择会话或新建", hasPrev: false);
        return r.Dir switch
        {
            StepDir.Next when r.IsNew => store.NewSession(string.IsNullOrEmpty(r.Value) ? "新会话" : r.Value),
            StepDir.Next => r.Value,
            _ => null,
        };
    }

    /// <summary>单步命令通用流程：取 active → 前置校验 → 向导步骤 → 更新 active</summary>
    private static void RunConfig(string cmd, bool isConnect, params StepFn[] steps)
    {
        StepState s;
        if (isConnect)
        {
            s = new(new());
        }
        else
        {
            var cfg = ConfigStore.Load();
            var active = cfg.Providers.FirstOrDefault(p => p.Name == cfg.Active) ?? new ProviderEntry { Name = cfg.Active };
            if (string.IsNullOrEmpty(active.Name) || string.IsNullOrEmpty(active.BaseUrl))
            {
                ShowMessage(cmd, "暂无提供商，先 /connect", "确定");
                return;
            }
            s = new(active);
        }
        var step = 0;
        while (step >= 0 && step < steps.Length)
        {
            var dir = steps[step]($"{cmd} {step + 1}/{steps.Length}", s, step > 0);
            if (dir == StepDir.Cancel) return;
            step = dir == StepDir.Next ? step + 1 : Math.Max(0, step - 1);
        }

        var latest = ConfigStore.Load();
        ConfigStore.Save(latest with
        {
            Active = s.Entry.Name,
            Providers = [.. latest.Providers.Where(p => p.Name != s.Entry.Name), s.Entry],
        });
    }

    // ===== 步骤函数（connect/key/model/variants 命令复用） =====

    /// <summary>步骤：base-url 列表（已有 provider 的 base-url + 新建）。空输入留在本步重试。</summary>
    private static StepDir StepBaseUrl(string title, StepState s, bool hasPrev)
    {
        var cfg = ConfigStore.Load();
        var labels = cfg.Providers.Select(p => p.BaseUrl).ToArray();
        var values = cfg.Providers.Select(p => p.Name).ToArray();
        var r = ListPickStep(title, labels, values, "＋ 新建", "Base URL:",
            false, "选择或新建提供商", hasPrev);
        if (r.Dir != StepDir.Next) return r.Dir;
        if (r.IsNew && string.IsNullOrEmpty(r.Value)) return StepDir.Prev;   // 空输入留本步
        s.Entry = r.IsNew
            ? new ProviderEntry { Name = r.Value, BaseUrl = r.Value }
            : cfg.Providers.First(p => p.Name == r.Value);
        return StepDir.Next;
    }

    /// <summary>步骤：key 列表（各 provider 打码 key，只显示 key 本身 + 新建）。</summary>
    private static StepDir StepKey(string title, StepState s, bool hasPrev)
    {
        var cfg = ConfigStore.Load();
        var labels = cfg.Providers.Select(p => !string.IsNullOrEmpty(p.ApiKey) ? Mask(p.ApiKey) : "（无 key）").ToArray();
        var values = cfg.Providers.Select(p => p.ApiKey).ToArray();
        return PickField(title, s, hasPrev, new PickOptions(
            labels, values, "＋ 新建", "新 API Key:", Secret: true, $"提供商 {s.Entry.Name}", s.Entry.ApiKey,
            (e, v) => e with { ApiKey = v }));
    }

    /// <summary>步骤：model 列表（真实模型目录：优先 API GET /models 拉取，失败回退"已配置过的模型"）+ 「＋ 新建模型」手输。</summary>
    private static StepDir StepModel(string title, StepState s, bool hasPrev)
    {
        var cfg = ConfigStore.Load();
        var known = cfg.Providers.Select(p => p.Model).Where(m => !string.IsNullOrEmpty(m));
        string[] api = [];
        try
        {
            api = new LlmClient(new ProviderConfig { BaseUrl = s.Entry.BaseUrl, ApiKey = s.Entry.ApiKey })
                .ListModelsAsync().GetAwaiter().GetResult();
        }
        catch { }
        var models = (api.Length > 0 ? api.Concat(known) : known).Distinct().ToArray();
        return PickField(title, s, hasPrev, new PickOptions(
            models, models, "＋ 新建模型", "模型名:", Secret: false, $"选择或输入模型（当前 {s.Entry.Model}）", s.Entry.Model,
            (e, v) => e with { Model = v }));
    }

    /// <summary>步骤：variants 真实取值（按提供商：deepseek 官方 low/high/max；其余 OpenAI 标准 low/medium/high）。</summary>
    private static StepDir StepVariants(string title, StepState s, bool hasPrev)
    {
        var variants = LlmClient.VariantsFor(s.Entry.BaseUrl);
        return PickField(title, s, hasPrev, new PickOptions(
            variants, variants, null, "", Secret: false, $"推理变体（当前 {s.Entry.Variants}）", s.Entry.Variants,
            (e, v) => e with { Variants = v }));
    }

    /// <summary>字段步骤选项（PickField 的参数集）</summary>
    private sealed record PickOptions(
        string[] Labels, string[] Values, string? NewLabel, string InputLabel,
        bool Secret, string Hint, string EmptyDefault, Func<ProviderEntry, string, ProviderEntry> Set);

    /// <summary>通用字段步骤：列表选值（可新建输入）→ 更新 entry 字段。空输入保留原值。</summary>
    private static StepDir PickField(string title, StepState s, bool hasPrev, PickOptions o)
    {
        var r = ListPickStep(title, o.Labels, o.Values, o.NewLabel, o.InputLabel, o.Secret, o.Hint, hasPrev);
        if (r.Dir != StepDir.Next) return r.Dir;
        var value = r switch
        {
            { IsNew: false } => r.Value,
            { Value.Length: > 0 } => r.Value,
            _ => o.EmptyDefault,
        };
        s.Entry = o.Set(s.Entry, value);
        return StepDir.Next;
    }

    /// <summary>key 打码：前 8 后 4</summary>
    private static string Mask(string key) => key.Length <= 12 ? key : string.Concat(key[..8], "…", key[^4..]);

    /// <summary>通用模态消息弹窗（agent 主题；MessageBox 用默认主题会跳色，统一走这里）。
    /// 经公开的 App + UiDispatcher 保证在 UI 主线程运行。返回点击的按钮下标（0 起；Esc/关闭 = -1），
    /// 最后一个按钮为默认（Enter 触发）。</summary>
    public static int ShowMessage(string title, string message, params string[] buttons)
    {
        return UiDispatcher.Invoke(() =>
        {
            var result = -1;
            var dialog = new Dialog
            {
                Title = title,
                Width = Math.Max(50, Math.Min(90, message.Length / 2 + 20)),
                Height = Math.Clamp(message.Split('\n').Length + 7, 9, 18),
                X = Pos.Center(),
                Y = Pos.Center(),
                SchemeName = TuiRepl.ThemeName,
            };
            dialog.Add(new Label { X = 1, Y = 1, Width = Dim.Fill(2), Text = message });
            for (var i = 0; i < buttons.Length; i++)
            {
                var idx = i;
                var b = new Button { Text = buttons[i] };
                b.Accepting += (_, _) => { result = idx; dialog.RequestStop(); };
                dialog.AddButton(b);
            }
            if (buttons.Length > 0)
                dialog.DefaultAcceptView = dialog.Buttons[^1];   // 最后一个按钮 = 默认（Enter）
            TuiRepl.App.Run(dialog);
            return result;
        });
    }
}
